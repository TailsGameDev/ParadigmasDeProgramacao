{-
Fa ̧ca um exemplo ilustrativo utilizando os m ́etodosceilingefloorda classeRealFrac
-}

main = do
  putStr("\nceiling 3.7 == " ++show(ceiling 3.7) )
  putStr("\nfloor 3.7 == " ++show(floor 3.7) )
