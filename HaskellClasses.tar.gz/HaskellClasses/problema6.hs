{-
Fa ̧ca um exemplo ilustrativo utilizando os m ́etodosminemaxda classeOrd
-}

main = do
  putStr("min de 3 e 4 eh: "++show(min 3 4)++"\n")
  putStr("max de 3 e 4 eh: "++show(max 3 4)++"\n")
