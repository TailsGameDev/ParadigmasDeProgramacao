{-
Fa ̧ca um exemplo ilustrativo utilizando o m ́etodoabsda classeNum
-}

main = do
  putStr( "abs de -1 eh " ++ show(abs (-1) ) ++"\n" )
